#Exercise
setwd("//Users//isurupradeep//Desktop//it24102405")

#Question 01
data <- read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)

popmn<-mean(Weight.kg.)
popsd<-sd(Weight.kg.)

#Question 02
samples<-c()
n<-c()

for(i in 1:25){
  s<-sample(Weight.kg.,6,replace = TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('S',i))
}
colnames(samples)=n

s.means<-apply(samples,2,mean)
s.sd<-apply(samples,2,sd)

#Question 03
samplemean<-mean(s.means)
samplesd<-sd(s.means)
